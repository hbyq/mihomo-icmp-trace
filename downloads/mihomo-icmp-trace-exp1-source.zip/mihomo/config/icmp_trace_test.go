package config

import "testing"

func TestICMPTraceConfiguration(t *testing.T) {
	for _, enabled := range []bool{false, true} {
		var general General
		if err := parseTun(RawTun{ICMPTrace: enabled}, &DNS{}, &general); err != nil {
			t.Fatal(err)
		}
		if general.Tun.ICMPTrace != enabled {
			t.Fatal("ICMP trace flag lost during config conversion")
		}
	}
	if err := parseTun(RawTun{ICMPTrace: true, DisableICMPForwarding: true}, &DNS{}, &General{}); err == nil {
		t.Fatal("accepted mutually exclusive forwarding modes")
	}
}

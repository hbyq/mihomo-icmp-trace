package config

import "testing"

func TestICMPTraceRequiresListenerReload(t *testing.T) {
	a := Tun{}
	b := a
	b.ICMPTrace = true
	if a.Equal(b) {
		t.Fatal("ICMP trace toggle would not recreate the listener")
	}
}
